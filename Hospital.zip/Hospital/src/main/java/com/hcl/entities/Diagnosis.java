package com.hcl.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Diagnosis {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int patientID;
	private int diagnosisId;

	private String symptoms;
	private String diagnosisProvided;
	private String administeredBy;
	private String dateOfDiagnosis;
	private String followUpProvided;
	private String dateOfFollowUp;
	private String billAmount;
	private String cardNumber;
	private String modeOfPayment;

	public Diagnosis() {

	}

	public Diagnosis(int patientID, int diagnosisId, String symptoms, String diagnosisProvided, String administeredBy,
			String dateOfDiagnosis, String followUpProvided, String dateOfFollowUp, String billAmount,
			String cardNumber, String modeOfPayment) {
		super();
		this.patientID = patientID;
		this.diagnosisId = diagnosisId;
		this.symptoms = symptoms;
		this.diagnosisProvided = diagnosisProvided;
		this.administeredBy = administeredBy;
		this.dateOfDiagnosis = dateOfDiagnosis;
		this.followUpProvided = followUpProvided;
		this.dateOfFollowUp = dateOfFollowUp;
		this.billAmount = billAmount;
		this.cardNumber = cardNumber;
		this.modeOfPayment = modeOfPayment;
	}

	public int getPatientID() {
		return patientID;
	}

	public void setPatientID(int patientID) {
		this.patientID = patientID;
	}

	public int getDiagnosisId() {
		return diagnosisId;
	}

	public void setDiagnosisId(int diagnosisId) {
		this.diagnosisId = diagnosisId;
	}

	public String getSymptoms() {
		return symptoms;
	}

	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}

	public String getDiagnosisProvided() {
		return diagnosisProvided;
	}

	public void setDiagnosisProvided(String diagnosisProvided) {
		this.diagnosisProvided = diagnosisProvided;
	}

	public String getAdministeredBy() {
		return administeredBy;
	}

	public void setAdministeredBy(String administeredBy) {
		this.administeredBy = administeredBy;
	}

	public String getDateOfDiagnosis() {
		return dateOfDiagnosis;
	}

	public void setDateOfDiagnosis(String dateOfDiagnosis) {
		this.dateOfDiagnosis = dateOfDiagnosis;
	}

	public String getFollowUpProvided() {
		return followUpProvided;
	}

	public void setFollowUpProvided(String followUpProvided) {
		this.followUpProvided = followUpProvided;
	}

	public String getDateOfFollowUp() {
		return dateOfFollowUp;
	}

	public void setDateOfFollowUp(String dateOfFollowUp) {
		this.dateOfFollowUp = dateOfFollowUp;
	}

	public String getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(String billAmount) {
		this.billAmount = billAmount;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getModeOfPayment() {
		return modeOfPayment;
	}

	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

}
