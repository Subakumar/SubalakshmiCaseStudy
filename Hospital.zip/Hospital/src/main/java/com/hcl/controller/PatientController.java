package com.hcl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.entities.Patient;
import com.hcl.service.PatientService;

@Controller
public class PatientController {
	@Autowired
	private PatientService patientService;

	@RequestMapping(value = "/register")
	public String LoginPatient(Model model) {
		Patient patient = new Patient();
		model.addAttribute("patient", patient);

		return "Register";
	}

	@RequestMapping(value = "/savePatient", method = RequestMethod.POST)
	public String savePatient(@ModelAttribute("patient") Patient patient, Model model) {
		this.patientService.savePatient(patient);
		List<Patient> listAll = this.patientService.listPatient();

		return "Success";
	}
}
