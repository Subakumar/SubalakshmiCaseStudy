package com.hcl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.entities.Physician;
import com.hcl.service.PhysicianService;

@Controller
public class PhysicianController {
	@Autowired
	private PhysicianService physicianService;
	@RequestMapping(value="/physician")
	public String LoginPhysician(Model model) {
		Physician physician = new Physician();
		model.addAttribute("physician",physician);
		
		return "physician";
	}
		
		
	@RequestMapping(value="/savePhysician", method=RequestMethod.POST)
	public String savePhysician(@ModelAttribute("physician") Physician physician) {
	    this.physicianService.savePhysician(physician);
	    List<Physician> listAll = this.physicianService.listPhysician();
	    
	    
	    return "Success";
	}
	
}
