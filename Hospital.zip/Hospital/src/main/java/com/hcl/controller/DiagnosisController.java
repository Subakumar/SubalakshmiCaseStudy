package com.hcl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.entities.Diagnosis;
import com.hcl.service.DiagnosisService;


@Controller
public class DiagnosisController {
	@Autowired
	private DiagnosisService diagnosisService;
	@RequestMapping(value="/diagnosis")
	public String LoginDiagnosis(Model model) {
		Diagnosis diagnosis = new Diagnosis();
		model.addAttribute("diagnosis",diagnosis);
		
		return "Diagnosis";
	}
		
		
	@RequestMapping(value="/saveDiagnosis", method=RequestMethod.POST)
	public String saveDiagnosis(@ModelAttribute("diagnosis") Diagnosis diagnosis) {
	    this.diagnosisService.saveDiagnosis(diagnosis);
	    List<Diagnosis> listAll = this.diagnosisService.listDiagnosis();
	    
	    
	    return "Success";
	}
}
