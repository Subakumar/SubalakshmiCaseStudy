package com.hcl.dao;

public interface SearchDao {

}
