package com.hcl.dao;

import java.util.List;

import com.hcl.entities.Physician;



public interface PhysicianDao {
	public void savePhysician(Physician physician);
	public List<Physician> listPhysician();
	
	}

