package com.hcl.dao;

import java.util.List;

import com.hcl.entities.Patient;

public interface PatientDao {

	public void savePatient(Patient patient);
	public List<Patient> listPatient();
}
