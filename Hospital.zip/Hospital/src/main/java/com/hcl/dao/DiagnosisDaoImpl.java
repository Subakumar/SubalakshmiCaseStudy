package com.hcl.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.entities.Diagnosis;



@Repository
public class DiagnosisDaoImpl implements DiagnosisDao {

	private static final Logger logger = Logger.getLogger(DiagnosisDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}

	@Override
	public void saveDiagnosis(Diagnosis diagnosis) {
		Session session = this.sessionFactory.getCurrentSession();
		session.save(diagnosis);
		logger.info("Patient saved successfully, Patient Details="+diagnosis);
		
	}

	@Override
	public List<Diagnosis> listDiagnosis() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Diagnosis> diagnosisList = session.createQuery("from Diagnosis").list();
		for(Diagnosis d : diagnosisList){
			logger.info("Patient List:"+d);
		}
		return diagnosisList;
	}
	}

	

