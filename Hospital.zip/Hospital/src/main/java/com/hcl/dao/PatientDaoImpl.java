package com.hcl.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.entities.Patient;

@Repository
public class PatientDaoImpl implements PatientDao {
	private static final Logger logger = Logger.getLogger(PatientDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	public void savePatient(Patient patient) {
		Session session = this.sessionFactory.getCurrentSession();
		session.save(patient);
		logger.info("Patient saved successfully, Patient Details=" + patient);
	}

	@Override
	public List<Patient> listPatient() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Patient> patientList = session.createQuery("from Patient").list();
		for (Patient p : patientList) {
			logger.info("Patient List:" + p);
		}
		return patientList;
	}

}
