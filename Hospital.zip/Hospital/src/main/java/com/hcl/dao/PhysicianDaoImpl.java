package com.hcl.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.entities.Patient;
import com.hcl.entities.Physician;

@Repository
public class PhysicianDaoImpl implements PhysicianDao {

	private static final Logger logger = Logger.getLogger(PhysicianDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	public void savePhysician(Physician physician) {
		Session session = this.sessionFactory.getCurrentSession();
		session.save(physician);
		logger.info("Physician saved successfully, Physician Details=" + physician);
	}

	@Override
	public List<Physician> listPhysician() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Physician> physicianList = session.createQuery("from Physician").list();
		for (Physician p : physicianList) {
			logger.info("Physician List:" + p);
		}
		return physicianList;
	}

}
