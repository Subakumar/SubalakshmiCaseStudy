package com.hcl.dao;

import java.util.List;

import com.hcl.entities.Diagnosis;



public interface DiagnosisDao {
	public void saveDiagnosis(Diagnosis diagnosis);
	public List<Diagnosis> listDiagnosis();
}
