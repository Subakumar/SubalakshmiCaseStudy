package com.hcl.service;

import java.util.List;

import com.hcl.entities.Physician;

public interface PhysicianService {
	public void savePhysician(Physician physician);
	List<Physician> listPhysician();
	
}
