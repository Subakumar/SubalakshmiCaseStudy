package com.hcl.service;

import java.util.List;

import com.hcl.entities.Diagnosis;



public interface DiagnosisService {
	public void saveDiagnosis(Diagnosis diagnosis);
	public List<Diagnosis> listDiagnosis();
}
