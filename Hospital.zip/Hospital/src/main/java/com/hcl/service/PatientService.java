package com.hcl.service;

import java.util.List;

import com.hcl.entities.Patient;

public interface PatientService {
	public void savePatient(Patient patient);
	public List<Patient> listPatient();
}
