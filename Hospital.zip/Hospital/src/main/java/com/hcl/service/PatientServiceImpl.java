package com.hcl.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.PatientDao;
import com.hcl.entities.Patient;


@Service
public class PatientServiceImpl implements PatientService{

	@Autowired
	private PatientDao patientDao;
	
	public void setPatientDao(PatientDao patientDao) {
		this.patientDao= patientDao;
	}

	

	@Override
	@Transactional
	public void savePatient(Patient patient) {
		this.patientDao.savePatient(patient);
		
	}



	@Override
	@Transactional
	public List<Patient> listPatient() {
		
			return this.patientDao.listPatient();
		}

	}



