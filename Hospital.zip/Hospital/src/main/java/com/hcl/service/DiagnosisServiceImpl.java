package com.hcl.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.DiagnosisDao;

import com.hcl.entities.Diagnosis;

@Service
public class DiagnosisServiceImpl implements DiagnosisService {
	@Autowired
	private DiagnosisDao diagnosisDao;
	
	public void setDiagnosisService(DiagnosisDao diagnosisDao) {
		this.diagnosisDao = diagnosisDao;
	}

	

	@Override
	@Transactional
	public void saveDiagnosis(Diagnosis diagnosis) {
		this.diagnosisDao.saveDiagnosis(diagnosis);
		
	}

	@Override
	@Transactional
	public List<Diagnosis> listDiagnosis() {
		return this.diagnosisDao.listDiagnosis();
	}
}
