package com.hcl.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.PhysicianDao;
import com.hcl.entities.Physician;

@Service
public class PhysicianServiceImpl implements PhysicianService{
	@Autowired
	private PhysicianDao physicianDao;
	
	public void setPhysicianService(PhysicianDao physicianDao) {
		this.physicianDao = physicianDao;
	}

	@Override
	@Transactional
	public void savePhysician(Physician physician) {
		this.physicianDao.savePhysician(physician);
		
	}

	@Override
	@Transactional
	public List<Physician> listPhysician() {
		return this.physicianDao.listPhysician();
	}

	
}
